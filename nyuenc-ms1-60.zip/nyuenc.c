#include <stdio.h>
#include <stdlib.h>
#include <fcntl.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>

// For example, a file with the following content:
//   aaaaaabbbbbbbbba
// would be encoded (logically, as the numbers would be in binary format instead of ASCII) as:
//   a6b9a1
// Note that the exact format of the encoded file is important. 
// You will store the character in ASCII and the count
// as a 1-byte unsigned integer in binary format. 

// $ echo -n "aaaaaabbbbbbbbba" > file.txt
// $ xxd file.txt
// 0000000: 6161 6161 6161 6262 6262 6262 6262 6261  aaaaaabbbbbbbbba
// $ ./nyuenc file.txt > file.enc
// $ xxd file.enc
// 0000000: 6106 6209 6101                           a.b.a.

// You may have used read() or fread() before, 
// but one particularly efficient way is to use mmap(), 
// which maps a file into the memory address space. 
// Then, you can efficiently access each byte of the input file via pointers. 
// Read its man page and example.

// Store your data as a char[] or unsigned char[] and use write() or fwrite() 
// to write them to STDOUT. 
// Don’t use printf() or attempt to convert them to any human-readable format.

// Also keep in mind that you should never use string functions 
// (e.g., strcpy() or strlen()) on binary data as they may contain null bytes.

int handle_error(char *error) {
    printf("%s\n", error);
    exit(1);
}

int main(int argc, const char *const *argv) {
    int n, count, id = 0;
    char prev = 0;
    char curr = 0;
    char *buffer = malloc(65535);

    for (int i = 1; i < argc; i++){
        // Open file
        int fd = open(argv[i], O_RDONLY);
        if (fd == -1)
        handle_error("File error");

        // Get file size
        struct stat sb;
        if (fstat(fd, &sb) == -1)
        handle_error("File stat error");

        // Map file into memory
        char *addr = mmap(NULL, sb.st_size, PROT_READ, MAP_PRIVATE, fd, 0);
        if (addr == MAP_FAILED)
        handle_error("Map error");

        // printf("%d\n", sb.st_size);
        // printf("%s\n", addr);
        n = 0;

        while (n < sb.st_size) {
            curr = addr[n];
            if (count == 0){
                count = 1;
                prev = addr[n];
            } else if (curr == prev) {
                count++;
            } else {
                // printf("%c%c\n", prev, curr);
                buffer[id] = prev;
                buffer[id+1] = count;
                count = 1;
                prev = curr;
                id += 2;
            }
            n++;
        }
    }
    buffer[id] = prev;
    buffer[id+1] = count;
    count = 1;
    prev = curr;
    id += 2;
    // printf("id: %d, prev: %c, count: %d\n", id, prev, count);

    write(STDOUT_FILENO, buffer, id);
    free(buffer);
}
